import { Controller } from '@nestjs/common';

@Controller('token')
export class TokenController {}
